let dropdown = document.querySelectorAll('.dropdownable');

dropdown.forEach((el) => {
    let button = el.querySelector('a');
    let menu = el.querySelector('.dropdown-menu');
    let arrow = el.querySelector('.fa-arrow-down');

    button.onclick = (event) => {
        let menuClasses = menu.className.split(' ');
        
        if ( menuClasses.indexOf('show') == -1 ) {
            menu.classList.add('show');
            menu.classList.remove('hide');
            arrow.classList.add('hide');
            arrow.classList.remove('show');
        }
        else {
            menu.classList.remove('show');
            menu.classList.add('hide');
            arrow.classList.remove('hide');
            arrow.classList.add('show');
        }
    };
});